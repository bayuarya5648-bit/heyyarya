import axios from "axios"
import { useState } from "react"

export default function Home(){

 const [id,setId] = useState("")

 const order = async()=>{
  const res = await axios.post("http://localhost:5000/api/order/create",{
    game:"Mobile Legends",
    target:id,
    product:"86 Diamonds",
    price:20000
  })

  window.location.href = res.data.payment_url
 }

 return (
  <div className="min-h-screen flex justify-center items-center">
    <div className="bg-white p-6 rounded-xl shadow-lg">
      <h1 className="text-xl font-bold mb-3">Topup Game</h1>

      <input 
       className="border p-2 w-full"
       placeholder="Masukan ID Game"
       onChange={e=>setId(e.target.value)}
      />

      <button 
       onClick={order}
       className="bg-blue-600 text-white w-full mt-3 p-2 rounded">
       Beli Sekarang
      </button>
    </div>
  </div>
 )
}