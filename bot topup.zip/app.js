// Main Application JavaScript
class TopUpApp {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentCategory = 'all';
        this.cart = JSON.parse(localStorage.getItem('cart')) || [];
        this.init();
    }

    async init() {
        await this.loadProducts();
        this.setupEventListeners();
        this.renderGames();
        this.updateCartCount();
    }

    async loadProducts() {
        try {
            // Load from local data first, then try API
            const localProducts = await this.loadLocalProducts();
            this.products = localProducts;
            this.filteredProducts = localProducts;
            
            // Try to load from API
            const apiProducts = await this.loadFromAPI();
            if (apiProducts && apiProducts.length > 0) {
                this.products = apiProducts;
                this.filteredProducts = apiProducts;
            }
        } catch (error) {
            console.error('Error loading products:', error);
            this.showError('Gagal memuat produk. Menggunakan data lokal.');
        }
    }

    async loadLocalProducts() {
        // Sample product data - in real app, this would come from API
        return [
            {
                id: 1,
                code: 'ml',
                name: 'Mobile Legends',
                category: 'mlbb',
                type: 'game',
                image: 'assets/images/mlbb.jpg',
                description: 'Mobile Legends: Bang Bang All Server',
                items: [
                    { id: '86', name: '86 Diamond', price: 20000 },
                    { id: '172', name: '172 Diamond', price: 39000 },
                    { id: '257', name: '257 Diamond', price: 58000 }
                ]
            },
            {
                id: 2,
                code: 'ff',
                name: 'Free Fire',
                category: 'battle',
                type: 'game',
                image: 'assets/images/freefire.jpg',
                description: 'Free Fire Diamonds',
                items: [
                    { id: '70', name: '70 Diamond', price: 10000 },
                    { id: '140', name: '140 Diamond', price: 20000 },
                    { id: '210', name: '210 Diamond', price: 30000 }
                ]
            },
            // Add more products as needed
        ];
    }

    async loadFromAPI() {
        try {
            const response = await fetch('/api/products');
            if (!response.ok) throw new Error('API response not ok');
            return await response.json();
        } catch (error) {
            console.log('Using local products data');
            return null;
        }
    }

    setupEventListeners() {
        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.handleFilter(e.target.dataset.filter);
            });
        });

        // Category cards
        document.querySelectorAll('.category-card').forEach(card => {
            card.addEventListener('click', (e) => {
                this.handleCategorySelect(card.dataset.category);
            });
        });

        // Cart icon
        document.querySelector('.cart-icon').addEventListener('click', () => {
            this.toggleCart();
        });

        // Close cart
        document.getElementById('closeCart').addEventListener('click', () => {
            this.toggleCart();
        });

        // Checkout button
        document.getElementById('checkoutBtn').addEventListener('click', () => {
            this.handleCheckout();
        });

        // Modal close
        document.querySelector('.close-modal').addEventListener('click', () => {
            this.closeModal();
        });

        // Close modal when clicking outside
        document.getElementById('productModal').addEventListener('click', (e) => {
            if (e.target.id === 'productModal') {
                this.closeModal();
            }
        });

        // Navigation smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Mobile menu toggle
        document.querySelector('.hamburger').addEventListener('click', () => {
            this.toggleMobileMenu();
        });
    }

    handleFilter(category) {
        this.currentCategory = category;
        
        // Update active filter button
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.filter === category);
        });

        // Filter products
        if (category === 'all') {
            this.filteredProducts = this.products.filter(p => p.type === 'game');
        } else {
            this.filteredProducts = this.products.filter(p => 
                p.type === 'game' && p.category === category
            );
        }

        this.renderGames();
    }

    handleCategorySelect(category) {
        // Scroll to games section and filter
        document.getElementById('games').scrollIntoView({
            behavior: 'smooth'
        });

        setTimeout(() => {
            this.handleFilter(category);
        }, 500);
    }

    renderGames() {
        const grid = document.getElementById('gamesGrid');
        
        if (this.filteredProducts.length === 0) {
            grid.innerHTML = '<p class="no-products">Tidak ada produk yang ditemukan.</p>';
            return;
        }

        grid.innerHTML = this.filteredProducts.map(product => `
            <div class="game-card" data-product-id="${product.id}">
                <img src="${product.image}" alt="${product.name}" class="game-image" onerror="this.src='assets/images/placeholder.jpg'">
                <div class="game-content">
                    <h3 class="game-title">${product.name}</h3>
                    <p class="game-category">${this.getCategoryName(product.category)}</p>
                    <div class="game-price">Rp ${this.formatPrice(product.items[0]?.price || 0)}</div>
                    <div class="game-items">
                        ${product.items.slice(0, 3).map(item => 
                            `<span class="game-item">${item.name}</span>`
                        ).join('')}
                        ${product.items.length > 3 ? `<span class="game-item">+${product.items.length - 3} more</span>` : ''}
                    </div>
                    <button class="btn-add-cart" onclick="app.showProductDetail(${product.id})">
                        Pilih Item
                    </button>
                </div>
            </div>
        `).join('');

        // Add click event to game cards
        grid.querySelectorAll('.game-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.classList.contains('btn-add-cart')) {
                    const productId = card.dataset.productId;
                    this.showProductDetail(parseInt(productId));
                }
            });
        });
    }

    showProductDetail(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) return;

        const modalContent = document.getElementById('modalContent');
        modalContent.innerHTML = `
            <h2>${product.name}</h2>
            <p class="product-description">${product.description}</p>
            <img src="${product.image}" alt="${product.name}" class="product-image" onerror="this.src='assets/images/placeholder.jpg'">
            
            <div class="product-items">
                <h3>Pilih Item:</h3>
                <div class="items-grid">
                    ${product.items.map(item => `
                        <div class="item-card" data-item-id="${item.id}">
                            <div class="item-name">${item.name}</div>
                            <div class="item-price">Rp ${this.formatPrice(item.price)}</div>
                            <button class="btn-add-to-cart" onclick="app.addToCart(${productId}, '${item.id}')">
                                Tambah ke Keranjang
                            </button>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;

        document.getElementById('productModal').style.display = 'block';
    }

    addToCart(productId, itemId) {
        const product = this.products.find(p => p.id === productId);
        const item = product.items.find(i => i.id === itemId);
        
        if (!product || !item) return;

        const cartItem = {
            id: Date.now(),
            productId,
            productName: product.name,
            itemId,
            itemName: item.name,
            price: item.price,
            quantity: 1
        };

        this.cart.push(cartItem);
        this.saveCart();
        this.updateCartCount();
        this.showSuccess('Item berhasil ditambahkan ke keranjang!');
        this.closeModal();
    }

    removeFromCart(cartItemId) {
        this.cart = this.cart.filter(item => item.id !== cartItemId);
        this.saveCart();
        this.updateCartCount();
        this.renderCartItems();
    }

    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.cart));
    }

    updateCartCount() {
        const count = this.cart.reduce((total, item) => total + item.quantity, 0);
        document.querySelector('.cart-count').textContent = count;
    }

    toggleCart() {
        document.getElementById('cartSidebar').classList.toggle('active');
        if (document.getElementById('cartSidebar').classList.contains('active')) {
            this.renderCartItems();
        }
    }

    renderCartItems() {
        const cartItems = document.getElementById('cartItems');
        const cartTotal = document.getElementById('cartTotal');

        if (this.cart.length === 0) {
            cartItems.innerHTML = '<p class="empty-cart">Keranjang belanja kosong</p>';
            cartTotal.textContent = 'Rp 0';
            return;
        }

        const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        
        cartItems.innerHTML = this.cart.map(item => `
            <div class="cart-item">
                <div class="cart-item-info">
                    <h4>${item.productName}</h4>
                    <p>${item.itemName}</p>
                    <div class="cart-item-price">Rp ${this.formatPrice(item.price)}</div>
                </div>
                <button class="cart-item-remove" onclick="app.removeFromCart(${item.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');

        cartTotal.textContent = `Rp ${this.formatPrice(total)}`;
    }

    async handleCheckout() {
        if (this.cart.length === 0) {
            this.showError('Keranjang belanja kosong!');
            return;
        }

        try {
            // In real app, this would send to your backend
            const orderData = {
                items: this.cart,
                total: this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
                timestamp: new Date().toISOString()
            };

            // Simulate API call
            const orderId = await this.createOrder(orderData);
            
            this.showSuccess(`Order berhasil! ID: ${orderId}`);
            this.cart = [];
            this.saveCart();
            this.updateCartCount();
            this.toggleCart();
            
        } catch (error) {
            this.showError('Gagal membuat order. Silakan coba lagi.');
        }
    }

    async createOrder(orderData) {
        // Simulate API call
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve('ORD' + Date.now().toString().slice(-8));
            }, 1000);
        });
    }

    closeModal() {
        document.getElementById('productModal').style.display = 'none';
    }

    toggleMobileMenu() {
        const navMenu = document.querySelector('.nav-menu');
        navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
    }

    getCategoryName(category) {
        const categories = {
            'mlbb': 'Mobile Legends',
            'battle': 'Battle Royale',
            'moba': 'MOBA',
            'rpg': 'RPG',
            'sports': 'Sports',
            'casual': 'Casual Games'
        };
        return categories[category] || category;
    }

    formatPrice(price) {
        return new Intl.NumberFormat('id-ID').format(price);
    }

    showSuccess(message) {
        this.showNotification(message, 'success');
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span>${message}</span>
            <button onclick="this.parentElement.remove()">&times;</button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new TopUpApp();
});

// Add notification styles
const notificationStyles = `
    .notification {
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 1003;
        display: flex;
        align-items: center;
        gap: 1rem;
        max-width: 400px;
        animation: slideIn 0.3s ease;
    }
    
    .notification-success {
        background: var(--success);
    }
    
    .notification-error {
        background: var(--error);
    }
    
    .notification button {
        background: none;
        border: none;
        color: white;
        font-size: 1.2rem;
        cursor: pointer;
    }
    
    @keyframes slideIn {
        from { transform: translateX(100%); }
        to { transform: translateX(0); }
    }
`;

const styleSheet = document.createElement('style');
styleSheet.textContent = notificationStyles;
document.head.appendChild(styleSheet);