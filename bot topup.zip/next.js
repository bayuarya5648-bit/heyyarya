npx create-next-app frontend
cd frontend
npm install axios tailwindcss