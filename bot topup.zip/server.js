const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Sample products data
const products = [
    {
        id: 1,
        code: 'ml',
        name: 'Mobile Legends',
        category: 'mlbb',
        type: 'game',
        image: '/assets/images/mlbb.jpg',
        description: 'Mobile Legends: Bang Bang All Server',
        items: [
            { id: '86', name: '86 Diamond', price: 20000 },
            { id: '172', name: '172 Diamond', price: 39000 },
            { id: '257', name: '257 Diamond', price: 58000 }
        ]
    },
    // Add more products...
];

// API Routes
app.get('/api/products', (req, res) => {
    res.json(products);
});

app.post('/api/orders', (req, res) => {
    const { items, total, customer } = req.body;
    
    // Simulate order processing
    const order = {
        id: 'ORD' + Date.now(),
        items,
        total,
        customer,
        status: 'pending',
        createdAt: new Date()
    };
    
    res.json({ success: true, order });
});

app.get('/api/status', (req, res) => {
    res.json({ 
        status: 'online', 
        message: 'Server is running',
        timestamp: new Date()
    });
});

// Serve frontend
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`🌐 Website: http://localhost:${PORT}`);
});