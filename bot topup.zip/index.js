require("dotenv").config()
const express = require("express")
const cors = require("cors")

const app = express()
app.use(cors())
app.use(express.json())

app.use("/api/order", require("./routes/order"))

app.get("/", (req,res)=>{
 res.send("Topup API Running")
})

app.listen(5000, ()=>{
 console.log("Server running on port 5000")
})