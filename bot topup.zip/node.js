mkdir backend
cd backend
npm init -y
npm install express axios cors mongoose dotenv midtrans-client