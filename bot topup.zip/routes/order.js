const router = require("express").Router()
const { createPayment } = require("./payment")

router.post("/create", async(req,res)=>{
 const { game, target, product, price } = req.body

 const payment = await createPayment({
   id: "ORDER"+Date.now(),
   price
 })

 res.json({
   status:true,
   payment_url: payment.redirect_url
 })
})

module.exports = router