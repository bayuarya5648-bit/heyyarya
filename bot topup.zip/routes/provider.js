const axios = require("axios")

async function orderDigiflazz(data){
 return axios.post("https://api.digiflazz.com/v1/transaction",{
   username: process.env.DIGI_USER,
   buyer_sku_code: data.sku,
   customer_no: data.target,
   ref_id: data.ref
 },{
  headers:{
   Authorization: process.env.DIGI_KEY
  }
 })
}

module.exports = { orderDigiflazz }