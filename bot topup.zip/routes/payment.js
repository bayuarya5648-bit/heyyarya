const midtransClient = require("midtrans-client")

const snap = new midtransClient.Snap({
 isProduction : false,
 serverKey : process.env.MIDTRANS_SERVER_KEY
})

async function createPayment(order){
 const param = {
   transaction_details:{
     order_id: order.id,
     gross_amount: order.price
   }
 }

 return await snap.createTransaction(param)
}

module.exports = { createPayment }