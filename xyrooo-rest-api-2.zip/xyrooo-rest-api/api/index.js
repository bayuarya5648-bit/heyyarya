// Vercel serverless entry: semua /api/* diarahkan ke Express app
module.exports = require('../src/app');
