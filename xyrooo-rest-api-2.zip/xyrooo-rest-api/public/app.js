const $ = (id) => document.getElementById(id);
const origin = location.origin;
const esc = (s) => s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

function highlight(json) {
  return esc(json).replace(/("(?:\\.|[^"\\])*")(\s*:)?|\b(true|false|null)\b|-?\d+\.?\d*/g, (m, str, colon) => {
    if (str) return colon ? `<span class="k">${str}</span>${colon}` : `<span class="s">${str}</span>`;
    return `<span class="n">${m}</span>`;
  });
}

async function run() {
  const path = $('path').value.trim();
  $('status').textContent = 'Memuat…';
  const t0 = performance.now();
  try {
    const res = await fetch(path);
    const data = await res.json();
    $('status').textContent = `${res.status} ${res.ok ? 'OK' : 'Error'}`;
    $('out').innerHTML = highlight(JSON.stringify(data, null, 2));
  } catch (e) {
    $('status').textContent = 'Gagal';
    $('out').textContent = 'Tidak bisa menghubungi server. Pastikan path benar.';
  }
  $('time').textContent = Math.round(performance.now() - t0) + ' ms';
}
$('run').onclick = run;
$('path').addEventListener('keydown', (e) => e.key === 'Enter' && run());

let eps = [], cat = 'Semua';
function renderGrid() {
  $('grid').innerHTML = eps.filter((e) => cat === 'Semua' || e.category === cat).map((e, i) => `
    <article class="ep">
      <div class="row"><span class="tag">${e.method} · ${e.category}</span></div>
      <code>${esc(e.path)}</code>
      <p>${esc(e.desc)}</p>
      <div class="row">
        <button class="btn" data-try="${esc(e.path)}">Coba</button>
        <button class="btn ghost" data-copy="${esc(e.path)}">Salin cURL</button>
      </div>
    </article>`).join('');
}
function renderTabs() {
  const cats = ['Semua', ...new Set(eps.map((e) => e.category))];
  $('tabs').innerHTML = cats.map((c) => `<button class="tab ${c === cat ? 'on' : ''}" data-cat="${c}">${c}</button>`).join('');
}
document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-try],[data-copy],[data-cat],[data-chip]');
  if (!t) return;
  if (t.dataset.cat) { cat = t.dataset.cat; renderTabs(); renderGrid(); }
  if (t.dataset.try || t.dataset.chip) {
    $('path').value = t.dataset.try || t.dataset.chip;
    $('playground').scrollIntoView({ behavior: 'smooth' });
    run();
  }
  if (t.dataset.copy) {
    navigator.clipboard.writeText(`curl "${origin}${t.dataset.copy}"`);
    const old = t.textContent; t.textContent = 'Tersalin!'; setTimeout(() => (t.textContent = old), 1200);
  }
});

const snippets = {
  cURL: `curl "${origin}/api/random/quote"`,
  JavaScript: `const res = await fetch("${origin}/api/utility/uuid");\nconst data = await res.json();\nconsole.log(data.result.uuid);`,
  Python: `import requests\n\nr = requests.get("${origin}/api/text/hash", params={"text": "xyrooo", "algo": "sha256"})\nprint(r.json()["result"])`,
  'API Key': `curl -H "x-api-key: KUNCI_KAMU" "${origin}/api/utility/ip"`
};
function renderSnip(k) {
  $('ctabs').innerHTML = Object.keys(snippets).map((n) => `<button class="tab ${n === k ? 'on' : ''}" data-snip="${n}">${n}</button>`).join('');
  $('snippet').textContent = snippets[k];
}
$('ctabs').addEventListener('click', (e) => e.target.dataset.snip && renderSnip(e.target.dataset.snip));
renderSnip('cURL');

fetch('/api/endpoints').then((r) => r.json()).then((d) => {
  eps = d.result; renderTabs(); renderGrid();
  $('chips').innerHTML = eps.slice(0, 5).map((e) => `<button class="chip" data-chip="${esc(e.path)}">${esc(e.path.split('?')[0].replace('/api', ''))}</button>`).join('');
}).catch(() => ($('grid').innerHTML = '<p class="lead">Gagal memuat daftar endpoint.</p>'));
