# ⚡ Xyrooo Rest Api

Platform REST API full stack: backend Express + UI premium (ungu) statis. Siap deploy ke Vercel.

## Struktur
```
xyrooo-rest-api/
├── api/index.js            # Entry serverless Vercel (export Express app)
├── src/
│   ├── app.js              # Konfigurasi Express
│   ├── server.js           # Server lokal (npm run dev)
│   ├── routes/             # index, utility, text, random
│   ├── middleware/         # rateLimit, apiKey, errorHandler
│   ├── utils/response.js   # Format respons JSON
│   └── data/endpoints.js   # Dokumentasi endpoint (dipakai UI)
├── public/                 # index.html, style.css, app.js
├── vercel.json
├── .env.example
└── package.json
```

## Jalankan lokal
```bash
npm install
npm run dev     # http://localhost:3000
```

## Deploy ke Vercel
**Via CLI**
```bash
npm i -g vercel
vercel          # preview
vercel --prod   # production
```
**Via GitHub**: push repo → vercel.com/new → Import → Deploy (tanpa konfigurasi tambahan).

Environment variable (opsional, Project Settings → Environment Variables):
- `API_KEYS` — pisah koma; jika diisi, request wajib header `x-api-key`
- `RATE_LIMIT` — batas request/menit/IP (default 60)

## Tambah endpoint baru
1. Buat handler di `src/routes/` lalu daftarkan di `src/routes/index.js`
2. Tambahkan entri di `src/data/endpoints.js` → otomatis muncul di UI

> Catatan: rate limit memakai memori lokal. Untuk produksi, ganti dengan Upstash Redis / Vercel KV.
