const path = require('path');
const express = require('express');
const cors = require('cors');
const rateLimit = require('./middleware/rateLimit');
const apiKey = require('./middleware/apiKey');
const { notFound, errorHandler } = require('./middleware/errorHandler');
const routes = require('./routes');

const app = express();
app.set('trust proxy', true);
app.use(cors());
app.use(express.json({ limit: '100kb' }));

// Static UI (untuk local dev; di Vercel public/ dilayani otomatis)
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api', rateLimit, apiKey, routes);
app.use(notFound);
app.use(errorHandler);

module.exports = app;
