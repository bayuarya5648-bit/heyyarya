// Sumber tunggal dokumentasi: dipakai oleh /api/endpoints dan UI.
module.exports = [
  { category: 'System', method: 'GET', path: '/api/health', desc: 'Cek status server', params: [] },
  { category: 'Utility', method: 'GET', path: '/api/utility/uuid', desc: 'Generate UUID v4', params: [] },
  { category: 'Utility', method: 'GET', path: '/api/utility/time?tz=Asia/Jakarta', desc: 'Waktu sekarang per zona waktu', params: ['tz'] },
  { category: 'Utility', method: 'GET', path: '/api/utility/ip', desc: 'Lihat IP kamu', params: [] },
  { category: 'Utility', method: 'GET', path: '/api/utility/password?length=16', desc: 'Password acak yang kuat', params: ['length'] },
  { category: 'Text', method: 'GET', path: '/api/text/slugify?text=Halo Dunia Xyrooo', desc: 'Ubah teks jadi slug URL', params: ['text'] },
  { category: 'Text', method: 'GET', path: '/api/text/base64?text=xyrooo&mode=encode', desc: 'Encode / decode Base64', params: ['text', 'mode'] },
  { category: 'Text', method: 'GET', path: '/api/text/hash?text=xyrooo&algo=sha256', desc: 'Hash md5, sha1, sha256, sha512', params: ['text', 'algo'] },
  { category: 'Text', method: 'GET', path: '/api/text/count?text=Halo dunia yang indah', desc: 'Hitung karakter, kata, kalimat', params: ['text'] },
  { category: 'Random', method: 'GET', path: '/api/random/number?min=1&max=100', desc: 'Angka acak dalam rentang', params: ['min', 'max'] },
  { category: 'Random', method: 'GET', path: '/api/random/color', desc: 'Warna acak (HEX, RGB, HSL)', params: [] },
  { category: 'Random', method: 'GET', path: '/api/random/quote', desc: 'Kutipan acak', params: [] }
];
