exports.ok = (res, data, status = 200) =>
  res.status(status).json({ success: true, creator: 'Xyrooo', result: data });

exports.fail = (res, message, status = 400) =>
  res.status(status).json({ success: false, creator: 'Xyrooo', error: message });
