const crypto = require('crypto');
const router = require('express').Router();
const { ok, fail } = require('../utils/response');

router.get('/uuid', (req, res) => ok(res, { uuid: crypto.randomUUID() }));

router.get('/time', (req, res) => {
  const tz = req.query.tz || 'UTC';
  try {
    const now = new Date();
    const local = new Intl.DateTimeFormat('id-ID', { timeZone: tz, dateStyle: 'full', timeStyle: 'long' }).format(now);
    ok(res, { timezone: tz, iso: now.toISOString(), local, unix: Math.floor(now / 1000) });
  } catch {
    fail(res, 'Timezone tidak valid. Contoh: Asia/Jakarta');
  }
});

router.get('/ip', (req, res) => ok(res, { ip: req.ip, userAgent: req.get('user-agent') }));

router.get('/password', (req, res) => {
  const length = Math.min(Math.max(parseInt(req.query.length, 10) || 16, 8), 128);
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*';
  let out = '';
  for (let i = 0; i < length; i++) out += chars[crypto.randomInt(chars.length)];
  ok(res, { length, password: out });
});

module.exports = router;
