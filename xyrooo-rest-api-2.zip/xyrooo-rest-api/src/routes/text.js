const crypto = require('crypto');
const router = require('express').Router();
const { ok, fail } = require('../utils/response');

const need = (req, res) => {
  const t = req.query.text;
  if (!t) { fail(res, 'Parameter "text" wajib diisi.'); return null; }
  return String(t);
};

router.get('/slugify', (req, res) => {
  const text = need(req, res); if (text === null) return;
  const slug = text.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  ok(res, { text, slug });
});

router.get('/base64', (req, res) => {
  const text = need(req, res); if (text === null) return;
  const mode = req.query.mode === 'decode' ? 'decode' : 'encode';
  const result = mode === 'encode'
    ? Buffer.from(text, 'utf8').toString('base64')
    : Buffer.from(text, 'base64').toString('utf8');
  ok(res, { mode, result });
});

router.get('/hash', (req, res) => {
  const text = need(req, res); if (text === null) return;
  const algo = (req.query.algo || 'sha256').toLowerCase();
  if (!['md5', 'sha1', 'sha256', 'sha512'].includes(algo)) return fail(res, 'algo: md5, sha1, sha256, sha512');
  ok(res, { algo, hash: crypto.createHash(algo).update(text).digest('hex') });
});

router.get('/count', (req, res) => {
  const text = need(req, res); if (text === null) return;
  ok(res, {
    characters: text.length,
    charactersNoSpaces: text.replace(/\s/g, '').length,
    words: text.trim().split(/\s+/).filter(Boolean).length,
    sentences: (text.match(/[^.!?]+[.!?]*/g) || []).filter((s) => s.trim()).length
  });
});

module.exports = router;
