const crypto = require('crypto');
const router = require('express').Router();
const { ok, fail } = require('../utils/response');

const quotes = [
  { quote: 'Bangun sesuatu yang kamu sendiri mau pakai.', author: 'Xyrooo' },
  { quote: 'Sederhana itu sulit, tapi itu yang membuatnya berharga.', author: 'Xyrooo' },
  { quote: 'Kode terbaik adalah kode yang tidak perlu ditulis.', author: 'Xyrooo' },
  { quote: 'Kirim dulu, sempurnakan kemudian.', author: 'Xyrooo' },
  { quote: 'Konsistensi mengalahkan intensitas.', author: 'Xyrooo' }
];

router.get('/number', (req, res) => {
  const min = parseInt(req.query.min ?? 1, 10);
  const max = parseInt(req.query.max ?? 100, 10);
  if (Number.isNaN(min) || Number.isNaN(max) || min >= max) return fail(res, '"min" harus lebih kecil dari "max".');
  ok(res, { min, max, number: crypto.randomInt(min, max + 1) });
});

router.get('/color', (req, res) => {
  const [r, g, b] = [0, 0, 0].map(() => crypto.randomInt(256));
  const hex = '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('');
  const mx = Math.max(r, g, b) / 255, mn = Math.min(r, g, b) / 255, l = (mx + mn) / 2;
  const d = mx - mn;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  let h = 0;
  if (d) {
    if (mx === r / 255) h = ((g - b) / 255 / d) % 6;
    else if (mx === g / 255) h = (b - r) / 255 / d + 2;
    else h = (r - g) / 255 / d + 4;
    h = Math.round((h * 60 + 360) % 360);
  }
  ok(res, { hex, rgb: `rgb(${r}, ${g}, ${b})`, hsl: `hsl(${h}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)` });
});

router.get('/quote', (req, res) => ok(res, quotes[crypto.randomInt(quotes.length)]));

module.exports = router;
