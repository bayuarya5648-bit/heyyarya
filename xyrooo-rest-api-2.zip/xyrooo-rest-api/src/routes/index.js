const router = require('express').Router();
const { ok } = require('../utils/response');
const endpoints = require('../data/endpoints');

router.get('/health', (req, res) =>
  ok(res, { status: 'online', name: 'Xyrooo Rest Api', version: '1.0.0', uptime: process.uptime(), time: new Date().toISOString() })
);
router.get('/endpoints', (req, res) => ok(res, endpoints));

router.use('/utility', require('./utility'));
router.use('/text', require('./text'));
router.use('/random', require('./random'));

module.exports = router;
