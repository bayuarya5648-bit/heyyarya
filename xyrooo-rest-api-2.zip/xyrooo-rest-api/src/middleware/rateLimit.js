// In-memory limiter. Di serverless tiap instance punya memori sendiri,
// untuk produksi serius ganti dengan Upstash Redis / Vercel KV.
const hits = new Map();
const WINDOW = 60 * 1000;

module.exports = (req, res, next) => {
  const limit = parseInt(process.env.RATE_LIMIT || '60', 10);
  const ip = req.ip || 'unknown';
  const now = Date.now();
  const entry = hits.get(ip) && hits.get(ip).reset > now ? hits.get(ip) : { count: 0, reset: now + WINDOW };
  entry.count++;
  hits.set(ip, entry);
  res.set('X-RateLimit-Limit', limit);
  res.set('X-RateLimit-Remaining', Math.max(0, limit - entry.count));
  if (entry.count > limit) {
    return res.status(429).json({ success: false, creator: 'Xyrooo', error: 'Terlalu banyak request. Coba lagi sebentar.' });
  }
  if (hits.size > 5000) for (const [k, v] of hits) if (v.reset < now) hits.delete(k);
  next();
};
