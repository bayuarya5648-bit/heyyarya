const { fail } = require('../utils/response');

exports.notFound = (req, res) => fail(res, `Route ${req.method} ${req.path} tidak ditemukan.`, 404);

exports.errorHandler = (err, req, res, _next) => {
  console.error(err);
  fail(res, err.message || 'Internal server error', err.status || 500);
};
