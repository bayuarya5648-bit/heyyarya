const { fail } = require('../utils/response');

// Aktif hanya jika env API_KEYS diisi. /api/health & /api/endpoints tetap publik.
module.exports = (req, res, next) => {
  const keys = (process.env.API_KEYS || '').split(',').map((k) => k.trim()).filter(Boolean);
  if (!keys.length || ['/health', '/endpoints'].includes(req.path)) return next();
  const key = req.get('x-api-key') || req.query.apikey;
  if (!keys.includes(key)) return fail(res, 'API key tidak valid atau tidak ada.', 401);
  next();
};
