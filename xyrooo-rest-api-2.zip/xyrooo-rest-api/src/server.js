// Local development: npm run dev
const app = require('./app');
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`⚡ Xyrooo Rest Api → http://localhost:${port}`));
